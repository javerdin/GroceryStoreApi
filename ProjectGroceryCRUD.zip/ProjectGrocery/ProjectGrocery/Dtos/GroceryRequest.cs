﻿using System.Text.Json.Serialization;

namespace ProjectGrocery.Dtos
{
    public class GroceryRequest
    {
        public string GroceryName { get; set; } = null!;
        public decimal Price { get; set; }
        public string Category { get; set; } = null!;
    }
}
