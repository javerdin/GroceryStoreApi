﻿using Microsoft.AspNetCore.Mvc;
using ProjectGrocery.Dtos;
using System.Text.Json;

namespace ProjectGrocery.Controllers
{
    public class GroceryController : Controller
    {
        private readonly IHttpClientFactory _httpClient;

        public GroceryController(IHttpClientFactory httpClient)
        {
            _httpClient = httpClient;
        }

        JsonSerializerOptions options = new JsonSerializerOptions() { PropertyNameCaseInsensitive = true };

        // GET: EmployeesController
        public async Task<ActionResult> Index()
        {
            List<GroceryDTO> grocery = new List<GroceryDTO>();
            try
            {
                var client = _httpClient.CreateClient("GroceryApi");
                var response = await client.GetAsync("Grocery");
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();

                    var result = JsonSerializer.Deserialize<GenericResponse>(content, options);
                    if (result.HttpCode == System.Net.HttpStatusCode.OK)
                        grocery = JsonSerializer.Deserialize<List<GroceryDTO>>(result.Data.ToString(), options);


                    return View(grocery);
                }
                return View();

            }
            catch
            {
                return View("Error");
            }
        }


        // GET: GroceryController/Create
        public ActionResult Create()
        {

            return View();

        }

        // POST: EmployeesController/Create
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(GroceryRequest grocery)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var client = _httpClient.CreateClient("GroceryApi");
                    var response = await client.PostAsJsonAsync("Grocery", grocery);
                    if (response.IsSuccessStatusCode)
                    {
                        var content = await response.Content.ReadAsStringAsync();

                        var result = JsonSerializer.Deserialize<GenericResponse>(content, options);
                        if (result.HttpCode == System.Net.HttpStatusCode.OK)
                            return RedirectToAction(nameof(Index));
                    }
                }
                return View();
            }
            catch
            {
                return View("Error");
            }
        }
    }
}
